hive-rank
=========

The Rank Generic UDF in Hive