#!/bin/bash
echo "Starting kestrel in development mode..."

# find jar no matter what the root dir name
SOURCE="${BASH_SOURCE[0]}"
while [ -h "$SOURCE" ]; do
  cd "$(dirname "$SOURCE")"
  SOURCE="$(readlink "$SOURCE")"
done
ROOT_DIR="$(cd -P "$(dirname "$SOURCE")"/.. && pwd)"

java -server -Xmx1024m -Dstage=development -jar "$ROOT_DIR"/kestrel_2.9.2-2.4.4-SWIFTYPE04.jar
