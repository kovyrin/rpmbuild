/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.openx.data.jsonserde.json;

import org.junit.After;
import org.junit.AfterClass;
import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

/**
 *
 * @author rcongiu
 */
public class JSONObjectTest {
    @BeforeClass
    public static void setUpClass() throws Exception {
    }

    @AfterClass
    public static void tearDownClass() throws Exception {
    }
    
    @Before
    public void setUp() throws Exception {
    }
    
    @After
    public void tearDown() {
    }


    
//    
//    @Test
//    public void testCaseInsensitive() throws JSONException   { 
//        
//     String test1 = "{ \"filename\": \"test.txt\", \"meta\": { \"datas\": { \"INFO\": { \"foo\": \"bar\" } } } }";
//     
//     JSONObject obj = new JSONObject(test1);
//     
//     assertEquals("test.txt",obj.getString("filename"));
//     assertEquals("bar", obj.getJSONObject("meta").getJSONObject("INFO").getJSONObject("foo"));
//     
//    }
    
    
    
}
