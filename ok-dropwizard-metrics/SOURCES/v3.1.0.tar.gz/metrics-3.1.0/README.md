Metrics [![Build Status](https://secure.travis-ci.org/dropwizard/metrics.png)](http://travis-ci.org/dropwizard/metrics)
=======

*Capturing JVM- and application-level metrics. So you know what's going on.*

For more information, please see [the documentation](http://dropwizard.github.io/metrics/).


License
-------

Copyright (c) 2010-2013 Coda Hale, Yammer.com

Published under Apache Software License 2.0, see LICENSE
