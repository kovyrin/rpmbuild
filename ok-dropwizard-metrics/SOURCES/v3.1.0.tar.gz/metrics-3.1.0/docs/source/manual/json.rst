.. _manual-json:

############
JSON Support
############

Metrics comes with ``metrics-json``, which features two reusable modules for Jackson_.

.. _Jackson: http://wiki.fasterxml.com/JacksonHome

This allows for the serialization of all metric types and health checks to a standard,
easily-parsable JSON format.
