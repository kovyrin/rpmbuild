/* Stub for base/utils.c */
void get_next_valid_time(time_t pref_time, time_t *valid_time, timeperiod *tperiod) {}
int update_check_stats(int check_type, time_t check_time) {}
int move_check_result_to_queue(char *checkresult_file) {}
int check_time_against_period(time_t test_time, timeperiod *tperiod) {}
