/* Stub for base/logging.c */
int write_to_all_logs(char *buffer, unsigned long data_type) {}
