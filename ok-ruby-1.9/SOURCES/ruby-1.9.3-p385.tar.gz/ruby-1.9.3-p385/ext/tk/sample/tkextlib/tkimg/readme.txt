The script 'demo.rb' is based on 'demo.tcl' of Tcl/Tk's 'Img' extention.
Image data in 'demo.rb' is those of 'demo.tcl'.
Please read 'license_terms_of_Img_extension' file.
